dir: Transcript contains source code
dir: thd428 contains jar executable
